function LoginApp() {
  try {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-cyan-50" data-name="login-app" data-file="login-app.js">
        <LoginForm />
      </div>
    );
  } catch (error) {
    console.error('LoginApp component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<LoginApp />);
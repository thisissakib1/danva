function SignupApp() {
  try {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-cyan-50" data-name="signup-app" data-file="signup-app.js">
        <SignupForm />
      </div>
    );
  } catch (error) {
    console.error('SignupApp component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<SignupApp />);
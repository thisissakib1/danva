function LoginForm() {
  try {
    const [email, setEmail] = React.useState('');
    const [password, setPassword] = React.useState('');

    return (
      <div className="min-h-screen flex items-center justify-center py-12 px-4" data-name="login-form" data-file="components/LoginForm.js">
        <div className="max-w-md w-full space-y-8">
          <div className="text-center">
            <a href="index.html" className="inline-flex items-center mb-8">
              <div className="w-12 h-12 bg-gradient-to-br from-[var(--primary-color)] to-[var(--secondary-color)] rounded-xl flex items-center justify-center mr-3">
                <div className="icon-palette text-2xl text-white"></div>
              </div>
              <span className="text-3xl font-extrabold bg-gradient-to-r from-[var(--primary-color)] to-[var(--secondary-color)] bg-clip-text text-transparent">Danva</span>
            </a>
            
            <h2 className="text-3xl font-bold text-[var(--text-primary)]">Welcome back</h2>
            <p className="mt-2 text-[var(--text-secondary)]">Sign in to your account to continue designing</p>
          </div>

          <form className="mt-8 space-y-6 bg-white p-8 rounded-2xl shadow-lg">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                Email address
              </label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 border border-[var(--border-color)] rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--primary-color)] focus:border-transparent"
                placeholder="Enter your email"
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                Password
              </label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 border border-[var(--border-color)] rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--primary-color)] focus:border-transparent"
                placeholder="Enter your password"
              />
            </div>

            <div className="flex items-center justify-between">
              <label className="flex items-center">
                <input type="checkbox" className="rounded border-[var(--border-color)]" />
                <span className="ml-2 text-sm text-[var(--text-secondary)]">Remember me</span>
              </label>
              <a href="#" className="text-sm text-[var(--primary-color)] hover:underline">Forgot password?</a>
            </div>

            <button type="submit" className="w-full btn-primary py-4 text-lg">
              Sign in
            </button>

            <p className="text-center text-sm text-[var(--text-secondary)]">
              Don't have an account?{' '}
              <a href="signup.html" className="text-[var(--primary-color)] hover:underline font-medium">
                Sign up for free
              </a>
            </p>
          </form>
        </div>
      </div>
    );
  } catch (error) {
    console.error('LoginForm component error:', error);
    return null;
  }
}
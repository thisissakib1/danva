function Hero() {
  try {
    return (
      <section className="relative bg-gradient-to-br from-purple-50 via-blue-50 to-cyan-50 py-24 overflow-hidden" data-name="hero" data-file="components/Hero.js">
        {/* Animated background elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-10 w-32 h-32 bg-purple-200 rounded-full opacity-20 animate-pulse"></div>
          <div className="absolute top-40 right-20 w-24 h-24 bg-cyan-200 rounded-full opacity-30 animate-bounce"></div>
          <div className="absolute bottom-20 left-1/4 w-16 h-16 bg-amber-200 rounded-full opacity-25"></div>
          <div className="absolute top-1/3 right-1/3 w-20 h-20 bg-pink-200 rounded-full opacity-20"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Left Column */}
            <div className="text-center lg:text-left">
              <div className="mb-6">
                <div className="inline-flex items-center px-4 py-2 bg-white bg-opacity-80 rounded-full text-sm font-medium text-[var(--primary-color)] mb-4 shadow-sm">
                  <div className="icon-sparkles text-lg mr-2"></div>
                  New: AI-Powered Design Assistant
                </div>
              </div>
              
              <h1 className="text-5xl lg:text-7xl font-extrabold text-[var(--text-primary)] mb-8 leading-tight">
                Design anything.
                <span className="gradient-text block bg-clip-text text-transparent bg-gradient-to-r from-purple-600 via-blue-600 to-cyan-600 animate-pulse">
                  Publish anywhere.
                </span>
              </h1>
              
              <p className="text-xl lg:text-2xl text-[var(--text-secondary)] mb-10 max-w-2xl leading-relaxed">
                Create stunning graphics, presentations, videos, and more with Danva's 
                <span className="font-semibold text-[var(--primary-color)]"> free AI-powered</span> drag-and-drop design tool. 
                No design experience required.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-8">
                <button className="group bg-[var(--primary-color)] text-white px-8 py-4 rounded-xl font-semibold text-lg hover:bg-purple-700 transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl">
                  <span className="flex items-center justify-center">
                    Start designing now
                    <div className="icon-arrow-right text-lg ml-2 group-hover:translate-x-1 transition-transform"></div>
                  </span>
                </button>
                <button className="group bg-white text-[var(--text-primary)] px-8 py-4 rounded-xl font-semibold text-lg border-2 border-[var(--border-color)] hover:border-[var(--primary-color)] hover:shadow-lg transition-all duration-300">
                  <div className="flex items-center justify-center">
                    <div className="icon-play text-lg mr-2 group-hover:scale-110 transition-transform"></div>
                    Watch how it works
                  </div>
                </button>
              </div>

              <div className="flex items-center justify-center lg:justify-start space-x-8">
                <div className="text-sm text-[var(--text-secondary)] font-medium">Trusted by 100M+ creators</div>
                <div className="flex items-center space-x-4">
                  <div className="flex -space-x-2">
                    <div className="w-8 h-8 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full border-2 border-white"></div>
                    <div className="w-8 h-8 bg-gradient-to-r from-blue-400 to-cyan-400 rounded-full border-2 border-white"></div>
                    <div className="w-8 h-8 bg-gradient-to-r from-amber-400 to-orange-400 rounded-full border-2 border-white"></div>
                  </div>
                  <div className="flex text-yellow-400">
                    <div className="icon-star text-sm"></div>
                    <div className="icon-star text-sm"></div>
                    <div className="icon-star text-sm"></div>
                    <div className="icon-star text-sm"></div>
                    <div className="icon-star text-sm"></div>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column */}
            <div className="relative">
              {/* Main design canvas */}
              <div className="relative bg-white rounded-3xl shadow-2xl p-8 transform hover:scale-105 transition-all duration-500">
                <div className="aspect-video bg-gradient-to-br from-purple-100 via-blue-100 to-cyan-100 rounded-2xl relative overflow-hidden">
                  {/* Design elements */}
                  <div className="absolute inset-4 bg-white rounded-xl shadow-lg p-4">
                    <div className="grid grid-cols-3 gap-2 mb-4">
                      <div className="h-2 bg-purple-200 rounded animate-pulse"></div>
                      <div className="h-2 bg-cyan-200 rounded animate-pulse" style={{animationDelay: '0.5s'}}></div>
                      <div className="h-2 bg-amber-200 rounded animate-pulse" style={{animationDelay: '1s'}}></div>
                    </div>
                    <div className="flex items-center justify-center h-20">
                      <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-cyan-500 rounded-2xl flex items-center justify-center shadow-lg">
                        <div className="icon-palette text-2xl text-white"></div>
                      </div>
                    </div>
                    <div className="mt-4 space-y-2">
                      <div className="h-1 bg-gray-200 rounded w-3/4 animate-pulse"></div>
                      <div className="h-1 bg-gray-200 rounded w-1/2 animate-pulse" style={{animationDelay: '0.3s'}}></div>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Floating action buttons */}
              <div className="absolute -top-6 -left-6 w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center shadow-xl animate-bounce">
                <div className="icon-wand-2 text-2xl text-white"></div>
              </div>
              <div className="absolute -bottom-6 -right-6 w-16 h-16 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-2xl flex items-center justify-center shadow-xl">
                <div className="icon-download text-2xl text-white animate-pulse"></div>
              </div>
              <div className="absolute top-8 -right-4 w-12 h-12 bg-gradient-to-r from-amber-400 to-orange-500 rounded-xl flex items-center justify-center shadow-lg">
                <div className="icon-share-2 text-lg text-white"></div>
              </div>
              
              {/* Floating design elements */}
              <div className="absolute -top-2 right-1/4 w-8 h-8 bg-pink-300 rounded-full opacity-60 animate-ping"></div>
              <div className="absolute bottom-1/3 -left-2 w-6 h-6 bg-cyan-300 rounded-full opacity-70"></div>
            </div>
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('Hero component error:', error);
    return null;
  }
}

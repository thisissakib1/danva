function CourseGrid() {
  try {
    const courses = [
      { title: 'Design Fundamentals', level: 'Beginner', duration: '2 hours', students: '12K+' },
      { title: 'Logo Design Mastery', level: 'Intermediate', duration: '4 hours', students: '8K+' },
      { title: 'Social Media Graphics', level: 'Beginner', duration: '3 hours', students: '15K+' },
      { title: 'Brand Identity Design', level: 'Advanced', duration: '6 hours', students: '5K+' },
      { title: 'Typography Basics', level: 'Beginner', duration: '2.5 hours', students: '10K+' },
      { title: 'Color Theory', level: 'Intermediate', duration: '3 hours', students: '7K+' }
    ];

    return (
      <section className="py-20 bg-white" data-name="course-grid" data-file="components/CourseGrid.js">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-[var(--text-primary)] mb-4">
              Popular Courses
            </h2>
            <p className="text-xl text-[var(--text-secondary)] max-w-3xl mx-auto">
              Choose from our most popular design courses and start learning today.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {courses.map((course, index) => (
              <div key={index} className="course-card">
                <div className="aspect-video bg-gradient-to-br from-purple-100 to-cyan-100 flex items-center justify-center">
                  <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center shadow-lg">
                    <div className="icon-play text-2xl text-[var(--primary-color)]"></div>
                  </div>
                </div>
                
                <div className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      course.level === 'Beginner' ? 'bg-green-100 text-green-700' :
                      course.level === 'Intermediate' ? 'bg-yellow-100 text-yellow-700' :
                      'bg-red-100 text-red-700'
                    }`}>
                      {course.level}
                    </span>
                    <span className="text-sm text-[var(--text-secondary)]">{course.duration}</span>
                  </div>
                  
                  <h3 className="text-xl font-semibold text-[var(--text-primary)] mb-2">
                    {course.title}
                  </h3>
                  
                  <p className="text-[var(--text-secondary)] mb-4">
                    {course.students} students enrolled
                  </p>
                  
                  <button className="w-full btn-primary">
                    Start Course
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('CourseGrid component error:', error);
    return null;
  }
}
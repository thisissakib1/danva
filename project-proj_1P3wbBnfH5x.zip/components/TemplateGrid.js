function TemplateGrid({ selectedCategory, searchQuery }) {
  try {
    // Mock template data
    const templates = [
      { id: 1, title: 'Instagram Story Template', category: 'social', type: 'Instagram Story', premium: false },
      { id: 2, title: 'Business Presentation', category: 'presentation', type: 'Presentation', premium: true },
      { id: 3, title: 'Marketing Flyer', category: 'marketing', type: 'Flyer', premium: false },
      { id: 4, title: 'Resume Template', category: 'document', type: 'Resume', premium: false },
      { id: 5, title: 'Video Thumbnail', category: 'video', type: 'YouTube Thumbnail', premium: true },
      { id: 6, title: 'Business Card', category: 'print', type: 'Business Card', premium: false },
      { id: 7, title: 'Facebook Post', category: 'social', type: 'Facebook Post', premium: false },
      { id: 8, title: 'Company Profile', category: 'presentation', type: 'Presentation', premium: true },
      { id: 9, title: 'Event Poster', category: 'marketing', type: 'Poster', premium: false },
      { id: 10, title: 'Invoice Template', category: 'document', type: 'Invoice', premium: false },
      { id: 11, title: 'Intro Video', category: 'video', type: 'Video Template', premium: true },
      { id: 12, title: 'Brochure Design', category: 'print', type: 'Brochure', premium: false }
    ];

    // Filter templates
    const filteredTemplates = templates.filter(template => {
      const categoryMatch = selectedCategory === 'all' || template.category === selectedCategory;
      const searchMatch = searchQuery === '' || 
        template.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        template.type.toLowerCase().includes(searchQuery.toLowerCase());
      
      return categoryMatch && searchMatch;
    });

    return (
      <section className="py-12 bg-[var(--bg-light)]" data-name="template-grid" data-file="components/TemplateGrid.js">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Results Header */}
          <div className="flex justify-between items-center mb-8">
            <div>
              <h2 className="text-2xl font-bold text-[var(--text-primary)]">
                {filteredTemplates.length} templates found
              </h2>
              {searchQuery && (
                <p className="text-[var(--text-secondary)] mt-1">
                  Results for "{searchQuery}"
                </p>
              )}
            </div>
            
            <div className="flex items-center space-x-4">
              <select className="px-4 py-2 border border-[var(--border-color)] rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--primary-color)]">
                <option>Most Popular</option>
                <option>Newest</option>
                <option>Most Used</option>
              </select>
            </div>
          </div>

          {/* Template Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredTemplates.map((template) => (
              <div key={template.id} className="template-item">
                <div className="relative aspect-[3/4] bg-gradient-to-br from-purple-100 to-cyan-100 flex items-center justify-center">
                  {/* Premium Badge */}
                  {template.premium && (
                    <div className="absolute top-3 right-3 bg-[var(--accent-color)] text-white px-2 py-1 rounded-full text-xs font-medium">
                      PRO
                    </div>
                  )}
                  
                  <div className="text-center">
                    <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                      <div className="icon-image text-2xl text-[var(--primary-color)]"></div>
                    </div>
                    <p className="text-sm text-[var(--text-secondary)]">{template.type}</p>
                  </div>

                  {/* Hover Overlay */}
                  <div className="absolute inset-0 bg-black bg-opacity-0 hover:bg-opacity-30 transition-all duration-300 flex items-center justify-center opacity-0 hover:opacity-100">
                    <button className="bg-white text-[var(--primary-color)] px-4 py-2 rounded-lg font-medium transform scale-90 hover:scale-100 transition-transform">
                      Use Template
                    </button>
                  </div>
                </div>

                <div className="p-4">
                  <h3 className="font-semibold text-[var(--text-primary)] mb-1">{template.title}</h3>
                  <p className="text-sm text-[var(--text-secondary)]">{template.type}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Load More Button */}
          {filteredTemplates.length > 0 && (
            <div className="text-center mt-12">
              <button className="btn-primary px-8 py-3">
                Load more templates
              </button>
            </div>
          )}

          {/* No Results */}
          {filteredTemplates.length === 0 && (
            <div className="text-center py-16">
              <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <div className="icon-search text-3xl text-gray-400"></div>
              </div>
              <h3 className="text-2xl font-semibold text-[var(--text-primary)] mb-2">
                No templates found
              </h3>
              <p className="text-[var(--text-secondary)] mb-6">
                Try adjusting your search or browse different categories
              </p>
              <button 
                onClick={() => { setSelectedCategory('all'); setSearchQuery(''); }}
                className="btn-secondary"
              >
                View all templates
              </button>
            </div>
          )}
        </div>
      </section>
    );
  } catch (error) {
    console.error('TemplateGrid component error:', error);
    return null;
  }
}
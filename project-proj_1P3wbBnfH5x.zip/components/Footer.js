function Footer() {
  try {
    const footerSections = [
      {
        title: 'Product',
        links: ['Templates', 'Features', 'Pricing', 'Apps', 'What\'s new']
      },
      {
        title: 'Solutions',
        links: ['Marketing', 'Education', 'Small business', 'Enterprise', 'Nonprofits']
      },
      {
        title: 'Learn',
        links: ['Design school', 'Tutorials', 'Blog', 'Events', 'Resources']
      },
      {
        title: 'Support',
        links: ['Help center', 'Contact us', 'System status', 'Report content', 'Privacy policy']
      }
    ];

    return (
      <footer className="bg-[var(--text-primary)] text-white" data-name="footer" data-file="components/Footer.js">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="grid md:grid-cols-2 lg:grid-cols-6 gap-8">
            {/* Logo and Description */}
            <div className="lg:col-span-2">
              <div className="flex items-center mb-6">
                <div className="w-8 h-8 bg-[var(--primary-color)] rounded-lg flex items-center justify-center mr-3">
                  <div className="icon-palette text-lg text-white"></div>
                </div>
                <span className="text-2xl font-bold">Danva</span>
              </div>
              <p className="text-gray-300 mb-6 max-w-sm">
                Design anything. Publish anywhere. Create stunning graphics, presentations, and more with our free design tool.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors">
                  <div className="icon-facebook text-lg"></div>
                </a>
                <a href="#" className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors">
                  <div className="icon-twitter text-lg"></div>
                </a>
                <a href="#" className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors">
                  <div className="icon-instagram text-lg"></div>
                </a>
                <a href="#" className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors">
                  <div className="icon-linkedin text-lg"></div>
                </a>
              </div>
            </div>

            {/* Footer Links */}
            {footerSections.map((section, index) => (
              <div key={index}>
                <h3 className="font-semibold text-white mb-4">{section.title}</h3>
                <ul className="space-y-3">
                  {section.links.map((link, linkIndex) => (
                    <li key={linkIndex}>
                      <a href="#" className="text-gray-300 hover:text-white transition-colors">
                        {link}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="border-t border-gray-700 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <div className="text-gray-300 text-sm mb-4 md:mb-0">
              © 2025 Danva. All rights reserved.
            </div>
            <div className="flex space-x-6 text-sm">
              <a href="#" className="text-gray-300 hover:text-white transition-colors">Terms</a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">Privacy</a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">Cookies</a>
            </div>
          </div>
        </div>
      </footer>
    );
  } catch (error) {
    console.error('Footer component error:', error);
    return null;
  }
}

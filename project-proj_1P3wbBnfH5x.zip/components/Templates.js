function Templates() {
  try {
    const templateCategories = [
      { name: 'Social Media', count: '50,000+', icon: 'share-2' },
      { name: 'Presentations', count: '25,000+', icon: 'presentation' },
      { name: 'Marketing', count: '30,000+', icon: 'megaphone' },
      { name: 'Documents', count: '15,000+', icon: 'file-text' },
      { name: 'Video', count: '10,000+', icon: 'video' },
      { name: 'Print', count: '20,000+', icon: 'printer' }
    ];

    return (
      <section id="templates" className="py-20 bg-[var(--bg-light)]" data-name="templates" data-file="components/Templates.js">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-[var(--text-primary)] mb-4">
              150,000+ free templates
            </h2>
            <p className="text-xl text-[var(--text-secondary)] max-w-3xl mx-auto">
              Choose from thousands of professionally designed templates for every occasion and customize them to match your brand.
            </p>
          </div>

          {/* Template Categories */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 mb-12">
            {templateCategories.map((category, index) => (
              <div key={index} className="template-card text-center p-6">
                <div className="w-16 h-16 bg-[var(--secondary-color)] bg-opacity-10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <div className={`icon-${category.icon} text-2xl text-[var(--secondary-color)]`}></div>
                </div>
                <h3 className="font-semibold text-[var(--text-primary)] mb-1">{category.name}</h3>
                <p className="text-sm text-[var(--text-secondary)]">{category.count} templates</p>
              </div>
            ))}
          </div>

          {/* Sample Template Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((item) => (
              <div key={item} className="template-card">
                <div className="aspect-[3/4] bg-gradient-to-br from-purple-100 to-cyan-100 flex items-center justify-center">
                  <div className="text-center">
                    <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center mx-auto mb-2">
                      <div className="icon-layout text-lg text-[var(--primary-color)]"></div>
                    </div>
                    <p className="text-sm text-[var(--text-secondary)]">Template {item}</p>
                  </div>
                </div>
                <div className="p-4">
                  <h4 className="font-medium text-[var(--text-primary)]">Design Template {item}</h4>
                  <p className="text-sm text-[var(--text-secondary)] mt-1">Professional design</p>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <button className="btn-primary text-lg px-8 py-4">Browse all templates</button>
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('Templates component error:', error);
    return null;
  }
}
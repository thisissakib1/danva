function LearnHero() {
  try {
    return (
      <section className="bg-gradient-to-br from-purple-50 to-cyan-50 py-20" data-name="learn-hero" data-file="components/LearnHero.js">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-5xl font-bold text-[var(--text-primary)] mb-6">
              <span className="gradient-text">Learn</span> Design with Danva
            </h1>
            
            <p className="text-xl text-[var(--text-secondary)] mb-8 max-w-3xl mx-auto">
              Master the art of design with our free courses, tutorials, and resources. 
              From beginner to pro, we've got you covered.
            </p>

            <div className="flex flex-wrap justify-center gap-4 mb-12">
              <button className="btn-primary px-8 py-4 text-lg">Start Learning</button>
              <button className="btn-secondary px-8 py-4 text-lg">Browse Courses</button>
            </div>

            <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
              <div className="text-center">
                <div className="w-16 h-16 bg-[var(--primary-color)] bg-opacity-10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <div className="icon-play-circle text-2xl text-[var(--primary-color)]"></div>
                </div>
                <h3 className="font-semibold text-[var(--text-primary)] mb-2">Video Tutorials</h3>
                <p className="text-[var(--text-secondary)]">Step-by-step video guides</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-[var(--secondary-color)] bg-opacity-10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <div className="icon-book-open text-2xl text-[var(--secondary-color)]"></div>
                </div>
                <h3 className="font-semibold text-[var(--text-primary)] mb-2">Design Courses</h3>
                <p className="text-[var(--text-secondary)]">Comprehensive learning paths</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-[var(--accent-color)] bg-opacity-10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <div className="icon-users text-2xl text-[var(--accent-color)]"></div>
                </div>
                <h3 className="font-semibold text-[var(--text-primary)] mb-2">Community</h3>
                <p className="text-[var(--text-secondary)]">Connect with other designers</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('LearnHero component error:', error);
    return null;
  }
}
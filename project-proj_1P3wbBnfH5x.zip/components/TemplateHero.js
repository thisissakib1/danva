function TemplateHero({ searchQuery, setSearchQuery }) {
  try {
    return (
      <section className="bg-gradient-to-br from-purple-50 to-cyan-50 py-16" data-name="template-hero" data-file="components/TemplateHero.js">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl lg:text-5xl font-bold text-[var(--text-primary)] mb-6">
              150,000+ <span className="gradient-text">Free Templates</span>
            </h1>
            
            <p className="text-xl text-[var(--text-secondary)] mb-8 max-w-3xl mx-auto">
              Choose from thousands of professionally designed templates for every occasion. 
              Customize them to match your brand in minutes.
            </p>

            {/* Search Bar */}
            <div className="max-w-2xl mx-auto mb-8">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <div className="icon-search text-xl text-[var(--text-secondary)]"></div>
                </div>
                <input
                  type="text"
                  placeholder="Search templates..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-4 py-4 text-lg border border-[var(--border-color)] rounded-xl focus:outline-none focus:ring-2 focus:ring-[var(--primary-color)] focus:border-transparent"
                />
              </div>
            </div>

            {/* Popular Tags */}
            <div className="flex flex-wrap justify-center gap-3">
              <span className="text-sm text-[var(--text-secondary)]">Popular:</span>
              {['Instagram Post', 'Presentation', 'Logo', 'Flyer', 'Business Card'].map((tag) => (
                <button
                  key={tag}
                  onClick={() => setSearchQuery(tag)}
                  className="px-3 py-1 text-sm bg-white rounded-full border border-[var(--border-color)] hover:border-[var(--primary-color)] transition-colors"
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('TemplateHero component error:', error);
    return null;
  }
}
function Stats() {
  try {
    const stats = [
      { number: '100M+', label: 'Users worldwide', icon: 'users' },
      { number: '15B+', label: 'Designs created', icon: 'image' },
      { number: '190+', label: 'Countries', icon: 'globe' },
      { number: '5★', label: 'App store rating', icon: 'star' }
    ];

    return (
      <section className="py-20 bg-[var(--primary-color)]" data-name="stats" data-file="components/Stats.js">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              Trusted by millions of creators
            </h2>
            <p className="text-xl text-purple-100 max-w-3xl mx-auto">
              Join the global community of designers, marketers, and creators who use Danva every day.
            </p>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-white bg-opacity-20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <div className={`icon-${stat.icon} text-2xl text-white`}></div>
                </div>
                <div className="text-4xl font-bold text-white mb-2">{stat.number}</div>
                <div className="text-purple-100">{stat.label}</div>
              </div>
            ))}
          </div>

          <div className="mt-16 bg-white bg-opacity-10 rounded-3xl p-8 text-center">
            <h3 className="text-2xl font-bold text-white mb-4">
              Ready to start designing?
            </h3>
            <p className="text-purple-100 mb-6 max-w-2xl mx-auto">
              Join millions of users and create stunning designs today. No credit card required.
            </p>
            <button className="bg-white text-[var(--primary-color)] px-8 py-4 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
              Get started for free
            </button>
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('Stats component error:', error);
    return null;
  }
}
function TemplateFilters({ selectedCategory, setSelectedCategory }) {
  try {
    const categories = [
      { id: 'all', name: 'All Templates', count: '150,000+', icon: 'grid-3x3' },
      { id: 'social', name: 'Social Media', count: '50,000+', icon: 'share-2' },
      { id: 'presentation', name: 'Presentations', count: '25,000+', icon: 'presentation' },
      { id: 'marketing', name: 'Marketing', count: '30,000+', icon: 'megaphone' },
      { id: 'document', name: 'Documents', count: '15,000+', icon: 'file-text' },
      { id: 'video', name: 'Video', count: '10,000+', icon: 'video' },
      { id: 'print', name: 'Print', count: '20,000+', icon: 'printer' }
    ];

    return (
      <section className="py-8 bg-white border-b border-[var(--border-color)]" data-name="template-filters" data-file="components/TemplateFilters.js">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap gap-4 justify-center">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`category-filter ${selectedCategory === category.id ? 'active' : ''}`}
              >
                <div className="flex items-center space-x-2">
                  <div className={`icon-${category.icon} text-lg`}></div>
                  <span className="font-medium">{category.name}</span>
                  <span className="text-sm opacity-75">({category.count})</span>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('TemplateFilters component error:', error);
    return null;
  }
}
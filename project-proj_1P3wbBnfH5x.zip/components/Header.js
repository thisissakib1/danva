function Header() {
  try {
    const [isMenuOpen, setIsMenuOpen] = React.useState(false);

    const navigateToSection = (sectionId) => {
      const element = document.getElementById(sectionId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
        setIsMenuOpen(false);
      } else {
        window.location.href = `index.html#${sectionId}`;
      }
    };

    return (
      <header className="sticky top-0 bg-white/95 backdrop-blur-sm border-b border-[var(--border-color)] z-50 shadow-sm" data-name="header" data-file="components/Header.js">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-18">
            {/* Logo */}
            <a href="index.html" className="flex items-center group">
              <div className="w-10 h-10 bg-gradient-to-br from-[var(--primary-color)] to-[var(--secondary-color)] rounded-xl flex items-center justify-center mr-3 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                <div className="icon-palette text-xl text-white"></div>
              </div>
              <span className="text-3xl font-extrabold bg-gradient-to-r from-[var(--primary-color)] to-[var(--secondary-color)] bg-clip-text text-transparent">Danva</span>
            </a>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-1">
              <a href="templates.html" className="relative px-4 py-2 text-[var(--text-secondary)] hover:text-[var(--primary-color)] font-medium transition-all duration-300 rounded-lg hover:bg-purple-50 group">
                <span className="relative z-10">Templates</span>
                <div className="absolute inset-0 bg-gradient-to-r from-[var(--primary-color)] to-[var(--secondary-color)] rounded-lg opacity-0 group-hover:opacity-10 transition-opacity"></div>
              </a>
              <button onClick={() => navigateToSection('features')} className="relative px-4 py-2 text-[var(--text-secondary)] hover:text-[var(--primary-color)] font-medium transition-all duration-300 rounded-lg hover:bg-purple-50 group">
                <span className="relative z-10">Features</span>
                <div className="absolute inset-0 bg-gradient-to-r from-[var(--primary-color)] to-[var(--secondary-color)] rounded-lg opacity-0 group-hover:opacity-10 transition-opacity"></div>
              </button>
              <button onClick={() => navigateToSection('pricing')} className="relative px-4 py-2 text-[var(--text-secondary)] hover:text-[var(--primary-color)] font-medium transition-all duration-300 rounded-lg hover:bg-purple-50 group">
                <span className="relative z-10">Pricing</span>
                <div className="absolute inset-0 bg-gradient-to-r from-[var(--primary-color)] to-[var(--secondary-color)] rounded-lg opacity-0 group-hover:opacity-10 transition-opacity"></div>
              </button>
              <a href="learn.html" className="relative px-4 py-2 text-[var(--text-secondary)] hover:text-[var(--primary-color)] font-medium transition-all duration-300 rounded-lg hover:bg-purple-50 group">
                <span className="relative z-10">Learn</span>
                <div className="absolute inset-0 bg-gradient-to-r from-[var(--primary-color)] to-[var(--secondary-color)] rounded-lg opacity-0 group-hover:opacity-10 transition-opacity"></div>
              </a>
            </nav>

            {/* Desktop Buttons */}
            <div className="hidden md:flex items-center space-x-3">
              <a href="login.html" className="px-6 py-2 text-[var(--text-primary)] hover:text-[var(--primary-color)] font-medium transition-colors rounded-lg hover:bg-gray-50">
                Log in
              </a>
              <a href="signup.html" className="bg-gradient-to-r from-[var(--primary-color)] to-[var(--secondary-color)] text-white px-6 py-3 rounded-xl font-semibold hover:shadow-lg hover:scale-105 transition-all duration-300 flex items-center">
                Sign up for free
                <div className="icon-arrow-right text-sm ml-2"></div>
              </a>
            </div>

            {/* Mobile menu button */}
            <button 
              className="md:hidden p-3 rounded-lg hover:bg-gray-100 transition-colors"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              <div className={`icon-${isMenuOpen ? 'x' : 'menu'} text-xl text-[var(--text-primary)]`}></div>
            </button>
          </div>

          {/* Mobile menu */}
          {isMenuOpen && (
            <div className="md:hidden py-6 border-t border-[var(--border-color)] bg-white/95 backdrop-blur-sm">
              <div className="flex flex-col space-y-3">
                <a href="templates.html" className="px-4 py-3 text-[var(--text-secondary)] hover:text-[var(--primary-color)] hover:bg-purple-50 rounded-lg transition-all font-medium">Templates</a>
                <button onClick={() => navigateToSection('features')} className="px-4 py-3 text-[var(--text-secondary)] hover:text-[var(--primary-color)] hover:bg-purple-50 rounded-lg transition-all font-medium text-left">Features</button>
                <button onClick={() => navigateToSection('pricing')} className="px-4 py-3 text-[var(--text-secondary)] hover:text-[var(--primary-color)] hover:bg-purple-50 rounded-lg transition-all font-medium text-left">Pricing</button>
                <a href="learn.html" className="px-4 py-3 text-[var(--text-secondary)] hover:text-[var(--primary-color)] hover:bg-purple-50 rounded-lg transition-all font-medium">Learn</a>
                <div className="pt-4 space-y-3">
                  <a href="login.html" className="block w-full px-4 py-3 text-center bg-gray-50 text-[var(--text-primary)] rounded-lg font-medium hover:bg-gray-100 transition-colors">Log in</a>
                  <a href="signup.html" className="block w-full px-4 py-3 text-center bg-gradient-to-r from-[var(--primary-color)] to-[var(--secondary-color)] text-white rounded-lg font-semibold hover:shadow-lg transition-all">Sign up for free</a>
                </div>
              </div>
            </div>
          )}
        </div>
      </header>
    );
  } catch (error) {
    console.error('Header component error:', error);
    return null;
  }
}

function Pricing() {
  try {
    const plans = [
      {
        name: 'Free',
        price: '0',
        period: 'Forever free',
        features: [
          '5,000+ free templates',
          '1GB cloud storage',
          'Basic export options',
          'Community support'
        ],
        buttonText: 'Get started',
        popular: false
      },
      {
        name: 'Pro',
        price: '12.99',
        period: 'per month',
        features: [
          'Everything in Free',
          '100GB cloud storage',
          'Premium templates',
          'Brand kit & folders',
          'Priority support',
          'Remove Danva watermark'
        ],
        buttonText: 'Start free trial',
        popular: true
      },
      {
        name: 'Teams',
        price: '14.99',
        period: 'per user/month',
        features: [
          'Everything in Pro',
          'Unlimited cloud storage',
          'Team collaboration',
          'Admin controls',
          'Brand management',
          'Priority phone support'
        ],
        buttonText: 'Contact sales',
        popular: false
      }
    ];

    return (
      <section id="pricing" className="py-20 bg-white" data-name="pricing" data-file="components/Pricing.js">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-[var(--text-primary)] mb-4">
              Choose the perfect plan
            </h2>
            <p className="text-xl text-[var(--text-secondary)] max-w-3xl mx-auto">
              Start for free and upgrade when you're ready. All plans include our core design tools.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {plans.map((plan, index) => (
              <div key={index} className={`relative bg-white rounded-3xl p-8 shadow-lg hover:shadow-xl transition-shadow ${plan.popular ? 'ring-2 ring-[var(--primary-color)]' : 'border border-[var(--border-color)]'}`}>
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-[var(--primary-color)] text-white px-4 py-2 rounded-full text-sm font-medium">
                      Most Popular
                    </span>
                  </div>
                )}

                <div className="text-center mb-8">
                  <h3 className="text-2xl font-bold text-[var(--text-primary)] mb-2">{plan.name}</h3>
                  <div className="mb-2">
                    <span className="text-4xl font-bold text-[var(--text-primary)]">${plan.price}</span>
                    {plan.price !== '0' && <span className="text-[var(--text-secondary)] ml-1">/{plan.period.split(' ')[1]}</span>}
                  </div>
                  <p className="text-[var(--text-secondary)]">{plan.period}</p>
                </div>

                <ul className="space-y-4 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start">
                      <div className="icon-check text-lg text-green-500 mr-3 mt-0.5"></div>
                      <span className="text-[var(--text-secondary)]">{feature}</span>
                    </li>
                  ))}
                </ul>

                <button className={plan.popular ? 'btn-primary w-full' : 'btn-secondary w-full'}>
                  {plan.buttonText}
                </button>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <p className="text-[var(--text-secondary)]">
              Need something custom? 
              <a href="#" className="text-[var(--primary-color)] hover:underline ml-1">Contact our sales team</a>
            </p>
          </div>
        </div>
      </section>
    );
  } catch (error) {
    console.error('Pricing component error:', error);
    return null;
  }
}
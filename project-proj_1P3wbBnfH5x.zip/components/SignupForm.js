function SignupForm() {
  try {
    const [name, setName] = React.useState('');
    const [email, setEmail] = React.useState('');
    const [password, setPassword] = React.useState('');

    return (
      <div className="min-h-screen flex items-center justify-center py-12 px-4" data-name="signup-form" data-file="components/SignupForm.js">
        <div className="max-w-md w-full space-y-8">
          <div className="text-center">
            <a href="index.html" className="inline-flex items-center mb-8">
              <div className="w-12 h-12 bg-gradient-to-br from-[var(--primary-color)] to-[var(--secondary-color)] rounded-xl flex items-center justify-center mr-3">
                <div className="icon-palette text-2xl text-white"></div>
              </div>
              <span className="text-3xl font-extrabold bg-gradient-to-r from-[var(--primary-color)] to-[var(--secondary-color)] bg-clip-text text-transparent">Danva</span>
            </a>
            
            <h2 className="text-3xl font-bold text-[var(--text-primary)]">Create your account</h2>
            <p className="mt-2 text-[var(--text-secondary)]">Start designing amazing graphics for free</p>
          </div>

          <form className="mt-8 space-y-6 bg-white p-8 rounded-2xl shadow-lg">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                Full name
              </label>
              <input
                id="name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-3 border border-[var(--border-color)] rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--primary-color)] focus:border-transparent"
                placeholder="Enter your full name"
              />
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                Email address
              </label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 border border-[var(--border-color)] rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--primary-color)] focus:border-transparent"
                placeholder="Enter your email"
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-[var(--text-primary)] mb-2">
                Password
              </label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 border border-[var(--border-color)] rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--primary-color)] focus:border-transparent"
                placeholder="Create a strong password"
              />
            </div>

            <div className="flex items-start">
              <input type="checkbox" className="mt-1 rounded border-[var(--border-color)]" />
              <span className="ml-2 text-sm text-[var(--text-secondary)]">
                I agree to the <a href="#" className="text-[var(--primary-color)] hover:underline">Terms of Service</a> and <a href="#" className="text-[var(--primary-color)] hover:underline">Privacy Policy</a>
              </span>
            </div>

            <button type="submit" className="w-full btn-primary py-4 text-lg">
              Create account
            </button>

            <p className="text-center text-sm text-[var(--text-secondary)]">
              Already have an account?{' '}
              <a href="login.html" className="text-[var(--primary-color)] hover:underline font-medium">
                Sign in here
              </a>
            </p>
          </form>
        </div>
      </div>
    );
  } catch (error) {
    console.error('SignupForm component error:', error);
    return null;
  }
}